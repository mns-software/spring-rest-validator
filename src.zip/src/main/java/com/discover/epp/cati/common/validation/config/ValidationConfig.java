package com.discover.epp.cati.common.validation.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import com.discover.epp.cati.common.validation.filter.ValidationFilter;
import com.discover.epp.cati.common.validation.interceptor.ValidationInterceptor;
import com.discover.epp.cati.common.validation.service.SwaggerValidationService;
import com.discover.epp.cati.common.validation.service.ValidationService;
import lombok.extern.slf4j.Slf4j;

/**
 * Configuration for Request Validation
 * <p>
 * Conditional on property epp.cati.common.validation.enabled - defaulted to false
 */
@Configuration
@EnableConfigurationProperties(ValidationProperties.class)
@ConditionalOnProperty(prefix = "epp.cati.common.validation", name = "enabled")
@Slf4j
public class ValidationConfig implements WebMvcConfigurer {

  private final ValidationProperties props;

  @Autowired
  public ValidationConfig(ValidationProperties props) {
    this.props = props;
    log.info("Validation enabled: {}", props.getSchemaLocation());
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void addInterceptors(InterceptorRegistry registry) {
    ValidationService service = new SwaggerValidationService(props.getSchemaLocation());
    registry.addInterceptor(new ValidationInterceptor(service)).excludePathPatterns(props.getExcludePathPatterns()).order(
      Ordered.LOWEST_PRECEDENCE);
  }

  @Bean
  public FilterRegistrationBean<ValidationFilter> validationFilterFilterRegistrationBean() {
    FilterRegistrationBean<ValidationFilter> registrationBean = new FilterRegistrationBean<>();
    registrationBean.setName("validationFilter");
    registrationBean.setFilter(new ValidationFilter());
    registrationBean.setOrder(props.getFilterOrder());
    return registrationBean;
  }
}
