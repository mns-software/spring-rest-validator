package com.discover.epp.cati.common.validation.service.parameter;

import java.util.Set;
import com.networknt.schema.ValidationMessage;
import io.swagger.models.parameters.Parameter;

/**
 * Parameter validator interface. All validators must implement it.
 *
 * @author msilco1
 */
public interface ParameterValidator {

  String supportedParameterType();

  boolean supports(Parameter p);

  Set<ValidationMessage> validate(String value, Parameter p);
}
