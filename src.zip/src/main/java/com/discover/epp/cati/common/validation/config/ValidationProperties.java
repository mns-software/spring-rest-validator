package com.discover.epp.cati.common.validation.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import lombok.Data;

@ConfigurationProperties(prefix = "epp.cati.common.validation")
@Data
public class ValidationProperties {

  /**
   * The OpenAPI/Swagger JSON schema location to be used for validation
   */
  private String schemaLocation = "swagger.json";

  /**
   * Array of excluded path patterns for the interceptor
   */
  private String[] excludePathPatterns = new String[0];

  /**
   * Order value for the filter (default 0)
   */
  private int filterOrder = 0;

}
