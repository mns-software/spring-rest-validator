package com.discover.epp.cati.common.validation.filter;

import java.io.IOException;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.filter.OncePerRequestFilter;

/**
 * Validator Filter that wraps the request to allow multiple reads of the body for validation
 *
 * @author msilco1
 */
public class ValidationFilter extends OncePerRequestFilter {

  @Override
  protected void doFilterInternal(HttpServletRequest request,
    HttpServletResponse response,
    FilterChain filterChain) throws ServletException, IOException {
    MultiReadHttpServletRequest wrappedRequest = new MultiReadHttpServletRequest(request);
    filterChain.doFilter(wrappedRequest, response);
  }

}
