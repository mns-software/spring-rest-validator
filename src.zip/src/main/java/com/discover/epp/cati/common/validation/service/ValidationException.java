package com.discover.epp.cati.common.validation.service;

import java.util.List;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>Thrown when there is a JSON schema validation error</p>
 */
public class ValidationException extends RuntimeException {

  private static final long serialVersionUID = 3803415613233272388L;
  private final List<String> validationErrors;

  public ValidationException(List<String> validationErrors) {
    super("[" + StringUtils.join(validationErrors, ",") + "]");
    this.validationErrors = validationErrors;
  }

  public List<String> getValidationErrors() {
    return validationErrors;
  }

}
