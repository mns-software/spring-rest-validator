package com.discover.epp.cati.common.validation.interceptor;

import static java.util.Objects.requireNonNull;

import javax.annotation.Nonnull;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;
import com.discover.epp.cati.common.validation.filter.MultiReadHttpServletRequest;
import com.discover.epp.cati.common.validation.service.ValidationService;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ValidationInterceptor extends HandlerInterceptorAdapter {

  private ValidationService validationService;

  public ValidationInterceptor(@Nonnull final ValidationService validationService) {
    requireNonNull(validationService, "validationService must not be null");
    this.validationService = validationService;
  }

  @Override
  public boolean preHandle(final HttpServletRequest servletRequest,
    final HttpServletResponse servletResponse,
    final Object handler) throws Exception {
    // only wrapped servlet requests can be validated - see: ValidationFilter
    if (!(servletRequest instanceof MultiReadHttpServletRequest)) {
      log.debug("Request validation disabled");
      return super.preHandle(servletRequest, servletResponse, handler);
    }

    validationService.validateRequest(servletRequest);

    return true;
  }
}
